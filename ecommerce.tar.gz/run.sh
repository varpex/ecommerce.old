#!/bin/sh

SCRIPTPATH=$(cd "$(dirname "$0")"; pwd)
"$SCRIPTPATH/ecommerce.exe" -importPath ecommerce -srcPath "$SCRIPTPATH/src" -runMode dev
